# Autokauppa

Tietokantojen hyödyntämisen toisessa tehtävässä harjoitellaan: 

+ MVC-mallin mukaista oliopohjaisen ohjelman ohjelmointia.

+ Tietoluokkien luomista tietomallin pohjalta (Tietokanta) MsSQL .

+ MVC-mallin Käyttöliittymän, tietoluokkien ja tietokannan toiminnallista yhdistämistä.
+ https://towardsdatascience.com/everything-you-need-to-know-about-mvc-architecture-3c827930b4c1

+ Olioiden käyttöä tietovarastona ja tiedon siirto-objektina.

Varsinaiseen ohjelmaan tehtävät muutokset ovat tekstitiedostoina solutionissa.


## Vaihe2
Tee ohjelman luokkien välisestä kommunikoinnista sekvenssikaavio 
